# Servidor — arquitectura prevista

Esta carpeta queda separada para la siguiente etapa.

El objetivo será mover la lógica crítica al servidor:
- autenticación
- personajes
- inventario
- combate
- drops
- mercado
- economía
- anti-cheat
- sincronización multiplayer

No se debe confiar en el cliente para entregar recompensas de valor real.
